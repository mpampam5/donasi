<section class="hero hero-game" style="background-image: url('<?=base_url()?>temp/front/banner-news.jpg');">
    <div class="overlay"></div>
    <div class="container">
      <div class="hero-block text-center">
        <div class="hero-center">
          <h2 class="hero-title"><?=$row->title?></h2>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <p style="color: grey; font-size: 20px;" class="p-l-100 p-r-100">
        <?=$row->deskripsi?>
      </p>
    </div>
  </section>

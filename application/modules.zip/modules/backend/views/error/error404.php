<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-5 mx-auto text-center">
                <h1 class="m-t-100">ERROR 404</h1>
                <h4><small class="text-danger">Maaf, Halaman yang anda inginkan tidak ditemukan.</small></h4>
                <a href="javascript:history.back()" class="btn btn-danger btn-sm"> Kembali Ke Halaman Sebelumnya</a>
                <a href="" class="btn btn-info btn-sm"><i class="fa fa-home"></i></a>
            </div>
        </div>
    </div>
</section>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends Front{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('Page_model','model');
  }

  function index($str="")
  {
    $this->template->set_title('Page | '.setting('title'));
    //meta seo
    $this->meta_tags->set_meta_tag('description', setting('title').' '.setting('alamat'));
    // *$this->meta_tags->unset_meta_tag('author');
    // * $this->meta_tags->add_robots_rule('NOINDEX');
    // * $this->meta_tags->add_keyword('php');
    //end meta seo


    if ($row = $this->model->get_data($str)) {
      $data = [
              'row' => $row
            ];

    $this->template->view('page/index',$data);
    }else{
      $this->_error404();
    }
    
  }


















}//end class




  <!-- footer -->
  <!-- <footer id="footer">
    <div class="container">
      <div class="footer-bottom">
        <p>Copyright &copy; 2017 <a href="https://themeforest.net/item/gameforest-responsive-gaming-html-theme/5007730" target="_blank">Gameforest</a>. All rights reserved.</p>
      </div>
    </div>
  </footer> -->

        <div class="modal fade" id="modalGue" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="modalTitle"></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
                </div>
                <div class="modal-body" id="modalContent" style="max-height: 487px; overflow-y: auto;"></div>
              </div>
            </div>
        </div>



  <!-- theme js -->
  <script src="<?=config_item('sty_back')?>js/theme.js"></script>

</body>
</html>
